using UnityEngine;

namespace Assignment03.StudentSolution
{
    public class Armor : Equipment
    {
        public int defense;

        public override void Equip(Player player)
        {
            base.Equip(player);
        }
    }
}
