using UnityEngine;

namespace Assignment03.StudentSolution
{
    public class Troll : MeleeEnemy
    {
        public int regenerationRate;

        public void Regenerate()
        {
            
        }
    }
}
