using UnityEngine;

namespace Assignment03.StudentSolution
{
    public class RangeEnemy : Enemy
    {
        public int range;

        public override void Attack(Entity target)
        {
            base.Attack(target);
        }
    }
}
