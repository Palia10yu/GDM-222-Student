using UnityEngine;

namespace Assignment03.StudentSolution
{
    public class Item 
    {
        public string name;
        private int value;

        public virtual void Use(Player player)
        {
            
        }
    }
}
