using UnityEngine;
using Debug = AssignmentSystem.Services.AssignmentDebugConsole;

namespace Assignment02.StudentSolution.LCT01
{
    public class Car
    {

    }

    public class LCT01SyntaxClass
    {
        public void Start()
        {
            // Student code start HERE ...

            // Student code ends HERE 
        }
    }
}
