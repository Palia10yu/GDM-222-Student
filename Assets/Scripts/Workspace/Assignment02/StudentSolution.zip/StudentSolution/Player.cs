using UnityEngine;

namespace Assignment03.StudentSolution
{
    public class Player : Entity
    {
        public int score;
        private Item[] items;

        public void CollectItem(Item item)
        {
            
        }

        protected void LevelUp()
        {
            
        }
    }
}
