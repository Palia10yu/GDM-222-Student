using UnityEngine;

namespace Assignment03.StudentSolution
{
    public class MeleeEnemy : Enemy
    {
        public int strength;

        public override void Attack(Entity target)
        {
            base.Attack(target);
        }
    }
}
