using UnityEngine;

namespace Assignment03.StudentSolution
{
    public class Orc : MeleeEnemy
    {
        public int rageLevel;

        public void Enrage()
        {
            
        }
    }
}
