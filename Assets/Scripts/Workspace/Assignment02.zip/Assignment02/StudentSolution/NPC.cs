using UnityEngine;

namespace Assignment03.StudentSolution
{
    public class NPC : Entity
    {
        public string dialogue;
        private bool isFriendly;

        public virtual void Interact(Player player)
        {
            
        }
    }
}
