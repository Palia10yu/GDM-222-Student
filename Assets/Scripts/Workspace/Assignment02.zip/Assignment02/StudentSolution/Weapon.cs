using UnityEngine;

namespace Assignment03.StudentSolution
{
    public class Weapon : Equipment
    {
        public int attackPower;

        public virtual void DealDamage(Entity Targat)
        {
            
        }
    }
}
