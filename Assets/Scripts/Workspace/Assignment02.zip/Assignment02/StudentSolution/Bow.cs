using UnityEngine;

namespace Assignment03.StudentSolution
{
    public class Bow : Weapon
    {
        public int range;

        public void Shoot()
        {
            
        }

        public override void Equip(Player player)
        {
            
        }

        public override void DealDamage(Entity Targat)
        {
        
        }
    }
}
